# 🚀 Junaid Tyagi - DevOps Portfolio (Two-Tier Application)

A modern, containerized portfolio application built with:
- **Frontend**: HTML/CSS/JS served by Nginx
- **Backend**: Flask (Python) REST API
- **Database**: MySQL
- **Orchestration**: Docker Compose

## 🏗️ Architecture