import os
from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_mysqldb import MySQL
import json

app = Flask(__name__)

# Configure MySQL from environment variables
app.config['MYSQL_HOST'] = os.environ.get('MYSQL_HOST', 'mysql')
app.config['MYSQL_USER'] = os.environ.get('MYSQL_USER', 'junaid')
app.config['MYSQL_PASSWORD'] = os.environ.get('MYSQL_PASSWORD', 'junaid123')
app.config['MYSQL_DB'] = os.environ.get('MYSQL_DB', 'portfolio_db')
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Initialize MySQL
mysql = MySQL(app)

# Your portfolio data
PORTFOLIO_DATA = {
    "name": "Junaid Alam Tyagi",
    "title": "DevOps & Cloud Engineer",
    "email": "junaidtyagi9555@gmail.com",
    "phone": "+91-9555888536",
    "location": "New Delhi, India",
    "github": "https://github.com/junaidtyagi9555",
    "linkedin": "https://www.linkedin.com/in/junaid-tyagi-8379b5225",
    
    "skills": {
        "cloud_devops": [
            "AWS (EC2, S3, CloudFront, IAM)",
            "Docker & Containerization",
            "Kubernetes",
            "Terraform",
            "CI/CD Pipelines",
            "Linux Administration"
        ],
        "development": [
            "Python Scripting",
            "Bash Scripting",
            "YAML/JSON"
        ],
        "tools": [
            "Git & GitHub",
            "AWS CLI",
            "CloudFormation",
            "Nginx"
        ]
    },
    
    "projects": [
        {
            "title": "AWS Cloud Resume",
            "description": "Hosted resume using S3, CloudFront, ACM with Infrastructure as Code",
            "technologies": ["S3", "CloudFront", "Terraform"],
            "github": "https://github.com/junaidtyagi9555/aws-s3-cloudfront-static-website"
        },
        {
            "title": "CloudFormation EC2 Web Server",
            "description": "Automated EC2 deployment with Apache using CloudFormation YAML",
            "technologies": ["CloudFormation", "EC2", "Apache"],
            "github": "https://github.com/junaidtyagi9555/aws-ec2-cloudformation-webserver"
        },
        {
            "title": "Dockerized Portfolio",
            "description": "Containerized web app with Nginx, multi-stage builds, and CI/CD pipeline",
            "technologies": ["Docker", "Nginx", "CI/CD"],
            "github": "https://github.com/junaidtyagi9555/DevOps-Projects"
        }
    ],
    
    "experience": [
        {
            "role": "Executive Engineer",
            "company": "Lava International",
            "period": "Jun 2024 - Present",
            "responsibilities": [
                "Managed enterprise IT infrastructure ensuring high availability",
                "Implemented AWS-based cloud solutions",
                "Automated workflows using AWS Lambda and CloudFormation"
            ]
        },
        {
            "role": "System Engineer",
            "company": "Jaypee Brothers Medical Publishers",
            "period": "Feb 2022 - Jun 2024",
            "responsibilities": [
                "Deployed and maintained AWS EC2 instances",
                "Configured Amazon S3 for secure data storage",
                "Assisted in implementing CI/CD pipelines"
            ]
        }
    ]
}

@app.route('/')
def portfolio():
    # Initialize database
    init_database()
    return render_template('index.html', data=PORTFOLIO_DATA)

@app.route('/api/portfolio')
def get_portfolio():
    return jsonify(PORTFOLIO_DATA)

@app.route('/api/messages', methods=['GET'])
def get_messages():
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT id, message, created_at FROM messages ORDER BY created_at DESC')
        messages = cur.fetchall()
        cur.close()
        return jsonify(messages)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/messages', methods=['POST'])
def add_message():
    try:
        new_message = request.json.get('message')
        if not new_message:
            return jsonify({'error': 'Message is required'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('INSERT INTO messages (message) VALUES (%s)', [new_message])
        mysql.connection.commit()
        message_id = cur.lastrowid
        cur.close()
        
        return jsonify({'id': message_id, 'message': new_message, 'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health')
def health_check():
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT 1')
        cur.close()
        return jsonify({'status': 'healthy', 'database': 'connected'})
    except Exception as e:
        return jsonify({'status': 'unhealthy', 'database': 'disconnected', 'error': str(e)}), 500

def init_database():
    try:
        cur = mysql.connection.cursor()
        # Create messages table if not exists
        cur.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        mysql.connection.commit()
        cur.close()
    except Exception as e:
        print(f"Database initialization error: {e}")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)